import React from 'react'
import './Home.css';
const Home = () => {
    return (
        
        <div className="Home pa6">
            <h1 id="H" className='f1 lh-title'>Music for everyone.</h1>
    
            <p id="P" className=' fw4 f3 lh-copy'>Millions of songs, no credit card needed</p>
            <div id="Button" className="mw5 pl5 center"><button id="bu" className='white grow' >Get Spotify FREE</button> </div>

        </div>
    
    );
}
// mw7-ns 
// ph6-ns
export default Home ;