export const SectionCardTypes = [
    {
      id: 1,
      title: 'Global Top 50',
      p:'Your daily update of the most played tracks right now.',
      source:require('./genres/Top50.jpg'),
    }
];