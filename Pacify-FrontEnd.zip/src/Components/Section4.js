import React from 'react';
import './Section4.css'


const Section4 =() => {



    return (

        <div className="section4">


          <h2>hellooo</h2>




        </div>
           

    );





}

export default Section4