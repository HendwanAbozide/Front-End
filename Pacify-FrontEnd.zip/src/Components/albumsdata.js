export const albumsdata = [
    {
      id: 0,
      albumimage:require('../album1.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    },
    {
      id: 1,
      albumimage:require('../album2.jpg'),
      albumname: 'Amr Diab',
      singer: 'Amir',
    },
    {
      id: 2,
      albumimage: require('../album3.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    },
    {
      id: 3,
      albumimage: require('../album4.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    },
    {
      id: 4,
      albumimage: require('../album5.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    },
    {
      id: 5,
      albumimage: require('../album6.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    },
    {
      id: 6, 
      albumimage: require('../album7.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    },
    {
      id: 7,
      albumimage: require('../album8.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    },
    {
      id: 8,
      albumimage: require('../album9.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    },
    {
      id: 9,
      albumimage:require('../album10.jpg'),
      albumname: 'Marron 5',
      singer: 'Maps',
    }
  ];
  