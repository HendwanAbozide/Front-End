export const likedsongsdata = [
    {
      id: 1,
      artist: 'Marron 5',
      songname: 'Maps',
    },
    {
      id: 2,
      artist: 'Cairokee',
      songname: 'Amir',
    },
    {
      id: 3,
      artist: 'Marron 5',
      songname: 'Maps',
    },
    {
      id: 4,
      artist: 'Marron 5',
      songname: 'Maps',
    },
    {
      id: 5,
      artist: 'Marron 5',
      songname: 'Maps',
    },
    {
      id: 6,
      artist: 'Marron 5',
      songname: 'Maps',
    },
    {
      id: 7,
      artist: 'Marron 5',
      songname: 'Maps',
    },
    {
      id: 8,
      artist: 'Marron 5',
      songname: 'Maps',
    },
    {
      id: 9,
      artist: 'Marron 5',
      songname: 'Maps',
    },
    {
      id: 10,
      artist: 'Marron 5',
      songname: 'Maps',
    }
  ];
  