export const playlistsdata = [
  {
    id: 1,
    playlistimage: require('../Rewind2018.jpg'),
    Title: 'Rewind the sound of 2018',
    Description: 'Listen to the best album',
   
  },
  {
    id: 2,
    playlistimage: require('../Mix.jpg'),
    Title: 'Daily mix-1',
    Description: 'Enjoy this',
  },
  {
    id: 3,
    playlistimage:require('../Mood.jpg'),
    Title: 'Mood Booster',
    Description: 'Listen and change you mood',
  },
  {
    id: 4,
    playlistimage:require('../Tophits.jpg'),
    Title: 'Pop-hits',
    Description: 'Maron5 and bla bla',
  },
  {
    id: 5,
    playlistimage:require('../SoftTophits.jpg'),
    Title: 'Ed-Sheren',
    Description: 'best album ever',
  },
  {
    id: 6,
    playlistimage:require('../memories.jpg'),
    Title: 'Memories',
    Description: 'Newest Album',
  },
  {
    id: 7,
    playlistimage:require('../Autumn.jpg'),
    Title: 'Autum louge',
    Description: 'Cool music, relife',
  },
  {
    id: 8,
    playlistimage:require('../brainfood.jpg'),
    Title: 'Brain food',
    Description: 'Stay calm and focused',
  },
  {
    id: 9,
    playlistimage:require('../Naharak.jpg'),
    Title: 'Naharak Zein',
    Description: 'Listen to them and enjoy',
  },
  {
    id: 10,
    playlistimage:require('../Adele.jpg'),
    Title: 'Adele',
    Description: 'Peak time zeft',
  }
];
