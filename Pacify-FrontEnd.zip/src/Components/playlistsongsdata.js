export const playlistsongsdata = [
    {
      id: 1,
      artist: 'Ears of light',
      album: 'life',
      songname: 'Life - Chill Version',
    },
    {
      id: 2,
      artist: 'Beauty',
      album: 'Vincente M',
      songname: 'Forever You',
    },
    {
      id: 3,
      artist: 'Floating Lights',
      album: 'All Passing By',
      songname: 'Memory Shrine',
    },
    {
      id: 4,
      artist: 'Falling Flowers',
      album: 'Eternal Winds',
      songname: 'Eternal Winds',
    },
    {
      id: 5,
      artist: 'Sofia',
      album: 'into the Stillness',
      songname: 'Sweet Feelings',
    },
    {
      id: 6,
      artist: 'Jan Thiel',
      album: 'Suda',
      songname: 'Suda',
    },
    {
      id: 7,
      artist: 'Marron 5',
      album: 'marron 5',
      songname: 'Maps',
    },
    {
      id: 8,
      artist: 'Floating Lights',
      album: 'Floating Lights',
      songname: 'Beginning',
    },
    {
      id: 9,
      artist: 'Sparkle',
      album: 'Sunset Thrill',
      songname: 'Morning',
    },
    {
      id: 10,
      artist: 'Falling Flowers',
      album: 'Eternal winds',
      songname: 'Lips in motion',
    }
  ];
  